'use client';

// app/components/Dashboard.tsx — UPGRADED
// Exact drop-in replacement for existing Dashboard.tsx
// ALL existing imports and utilities preserved:
//   calculateRiskScore, getThreatCategory, compareScans, 
//   calculateAnomalyScore, mockRuntimeEvents
//
// ADDED:
// ✅ 20 AWS security checks (was 3: S3, EC2, SG only)
// ✅ Recharts: severity pie chart + issues-by-service bar chart + risk trend line
// ✅ RAG AI: sends structured issues + shows retrieved CIS/NIST controls
// ✅ Isolation Forest scores displayed in CWPP panel
// ✅ CIS control badge on each issue card
// ✅ Per-issue remediation command (expandable click)
// ✅ Compliance Score in header
// ✅ Contributing anomaly features in CWPP cards

import { useEffect, useState, useCallback } from 'react';
import {
  Shield, Lock, Sparkles,
  Activity, Zap, TrendingUp, BarChart3, ShieldAlert, Cpu, Terminal,
  ChevronDown, ChevronUp, CheckCircle,
} from 'lucide-react';
import {
  PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line,
} from 'recharts';

// ── Your existing utilities (unchanged) ──────────────────────────────────────
import { calculateRiskScore, Issue as RiskIssue } from '../../utils/riskScore';
import { getThreatCategory } from '../../utils/threatCategory';
import { compareScans } from '../../utils/driftDetection';
import { calculateAnomalyScore, mockRuntimeEvents } from '../../services/runtimeMonitor';

// ─── TYPES ───────────────────────────────────────────────────────────────────
interface SecurityIssue {
  id: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  type: string;
  resource: string;
  description: string;
  region?: string;
  threatCategory?: string;
  riskScore?: number;
  // NEW fields for upgrade
  checkId?: string;
  cisControl?: string;
  remediationHint?: string;
}

interface DashboardStats {
  publicS3Buckets: number;
  publicInstances: number;
  openSecurityGroups: number;
  totalInstances: number;
  criticalIssues: number;
  highIssues: number;
  totalRiskScore: number;
}

interface SteampipeResponse { rows: Record<string, unknown>[]; }
interface RAGControl { id: string; framework: string; title: string; severity: string; }
interface TrendPoint { time: string; score: number; }

// ─── 20 AWS SECURITY CHECKS ───────────────────────────────────────────────────
interface CheckDef {
  id: string;
  sql: string;
  mapRow: (row: Record<string, unknown>) => SecurityIssue;
}

const AWS_CHECKS: CheckDef[] = [
  // S3
  { id:'S3_PUBLIC',
    sql:`SELECT name, block_public_acls, block_public_policy, ignore_public_acls, restrict_public_buckets, region
         FROM aws_s3_bucket
         WHERE NOT block_public_acls OR NOT block_public_policy OR NOT ignore_public_acls OR NOT restrict_public_buckets`,
    mapRow:(b)=>({ id:`s3-${b.name}`, checkId:'S3_PUBLIC', cisControl:'CIS-2.1.5',
      severity:'high', type:'Public S3 Bucket', resource:String(b.name), region:String(b.region),
      description:`Bucket "${b.name}" has Block Public Access disabled — ACLs:${b.block_public_acls?'✅':'❌'} Policy:${b.block_public_policy?'✅':'❌'} IgnoreACL:${b.ignore_public_acls?'✅':'❌'} Restrict:${b.restrict_public_buckets?'✅':'❌'}`,
      remediationHint:`aws s3api put-public-access-block --bucket ${b.name} --public-access-block-configuration BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true` })},
  { id:'S3_NO_ENC',
    sql:`SELECT name, region FROM aws_s3_bucket WHERE server_side_encryption_configuration IS NULL LIMIT 50`,
    mapRow:(b)=>({ id:`s3enc-${b.name}`, checkId:'S3_NO_ENC', cisControl:'CIS-2.1.2',
      severity:'medium', type:'S3 Bucket Without Encryption', resource:String(b.name), region:String(b.region),
      description:`Bucket "${b.name}" has no server-side encryption configured. Data at rest stored in plaintext.`,
      remediationHint:`aws s3api put-bucket-encryption --bucket ${b.name} --server-side-encryption-configuration '{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"AES256"}}]}'` })},
  // EC2
  { id:'EC2_PUBLIC',
    sql:`SELECT instance_id, instance_type, region, public_ip_address, public_dns_name, tags
         FROM aws_ec2_instance WHERE public_ip_address IS NOT NULL LIMIT 50`,
    mapRow:(i)=>{
      const tags = i.tags as Record<string,string>|undefined;
      const name = tags?.Name || i.instance_id;
      return { id:`ec2-${i.instance_id}`, checkId:'EC2_PUBLIC', cisControl:'CIS-5.6',
        severity:'medium', type:'Public EC2 Instance', resource:`${name} (${i.instance_type})`, region:String(i.region),
        description:`Instance "${i.instance_id}" is publicly accessible — IP: ${i.public_ip_address}${i.public_dns_name?' | DNS: '+i.public_dns_name:''}`,
        remediationHint:'Move instance to private subnet. Use Application Load Balancer or NAT Gateway for required internet connectivity.' };
    }},
  { id:'EC2_IMDSV2',
    sql:`SELECT instance_id, region, metadata_options ->> 'HttpTokens' as http_tokens
         FROM aws_ec2_instance WHERE metadata_options ->> 'HttpTokens' != 'required' AND state ->> 'Name' = 'running' LIMIT 50`,
    mapRow:(i)=>({ id:`imds-${i.instance_id}`, checkId:'EC2_IMDSV2', cisControl:'AWS-IMDSV2',
      severity:'high', type:'EC2 IMDSv2 Not Enforced', resource:String(i.instance_id), region:String(i.region),
      description:`Instance ${i.instance_id} allows IMDSv1 (HttpTokens=${i.http_tokens}). SSRF attacks can steal IAM credentials from the metadata service.`,
      remediationHint:`aws ec2 modify-instance-metadata-options --instance-id ${i.instance_id} --http-tokens required --http-put-response-hop-limit 1` })},
  // Security Groups
  { id:'SG_OPEN',
    sql:`SELECT group_id, group_name, description, region, vpc_id
         FROM aws_vpc_security_group WHERE ip_permissions::text LIKE '%0.0.0.0/0%' LIMIT 50`,
    mapRow:(sg)=>({ id:`sg-${sg.group_id}`, checkId:'SG_OPEN', cisControl:'CIS-5.3',
      severity:'critical', type:'Overly Permissive Security Group', resource:`${sg.group_name} (${sg.group_id})`, region:String(sg.region),
      description:`"${sg.group_name}" allows unrestricted inbound traffic (0.0.0.0/0)${sg.vpc_id?' in VPC: '+sg.vpc_id:''}${sg.description?' — '+sg.description:''}`,
      remediationHint:`aws ec2 revoke-security-group-ingress --group-id ${sg.group_id} --ip-permissions '[{"IpProtocol":"-1","IpRanges":[{"CidrIp":"0.0.0.0/0"}]}]'` })},
  { id:'SG_SSH',
    sql:`SELECT group_id, group_name, region FROM aws_vpc_security_group
         WHERE ip_permissions::text LIKE '%"toPort": 22%' AND ip_permissions::text LIKE '%0.0.0.0/0%' LIMIT 50`,
    mapRow:(sg)=>({ id:`sgsh-${sg.group_id}`, checkId:'SG_SSH', cisControl:'CIS-5.1',
      severity:'critical', type:'Open SSH Access (Port 22)', resource:`${sg.group_name} (${sg.group_id})`, region:String(sg.region),
      description:`"${sg.group_name}" allows unrestricted SSH (port 22) from 0.0.0.0/0. Exposed to brute-force and credential stuffing attacks.`,
      remediationHint:`aws ec2 revoke-security-group-ingress --group-id ${sg.group_id} --protocol tcp --port 22 --cidr 0.0.0.0/0` })},
  { id:'SG_RDP',
    sql:`SELECT group_id, group_name, region FROM aws_vpc_security_group
         WHERE ip_permissions::text LIKE '%"toPort": 3389%' AND ip_permissions::text LIKE '%0.0.0.0/0%' LIMIT 50`,
    mapRow:(sg)=>({ id:`sgrdp-${sg.group_id}`, checkId:'SG_RDP', cisControl:'CIS-5.2',
      severity:'critical', type:'Open RDP Access (Port 3389)', resource:`${sg.group_name} (${sg.group_id})`, region:String(sg.region),
      description:`"${sg.group_name}" allows unrestricted RDP (port 3389) from 0.0.0.0/0. Primary ransomware attack vector.`,
      remediationHint:`aws ec2 revoke-security-group-ingress --group-id ${sg.group_id} --protocol tcp --port 3389 --cidr 0.0.0.0/0` })},
  // IAM
  { id:'IAM_NO_MFA',
    sql:`SELECT name, user_id, mfa_enabled, password_last_used FROM aws_iam_user WHERE mfa_enabled = false LIMIT 50`,
    mapRow:(u)=>({ id:`iam-${u.user_id}`, checkId:'IAM_NO_MFA', cisControl:'CIS-1.10',
      severity:'critical', type:'IAM User Without MFA', resource:String(u.name), region:'global',
      description:`IAM user "${u.name}" has no MFA. Console access with password only. Last login: ${u.password_last_used||'never'}.`,
      remediationHint:`aws iam enable-mfa-device --user-name ${u.name} --serial-number arn:aws:iam::ACCOUNT_ID:mfa/${u.name} --authentication-code1 CODE1 --authentication-code2 CODE2` })},
  { id:'IAM_OLD_KEY',
    sql:`SELECT user_name, access_key_id, date_part('day', now() - create_date) as age_days
         FROM aws_iam_access_key WHERE status = 'Active' AND date_part('day', now() - create_date) > 90 LIMIT 50`,
    mapRow:(k)=>({ id:`iamkey-${k.access_key_id}`, checkId:'IAM_OLD_KEY', cisControl:'NIST-AC-2',
      severity:'high', type:'Stale IAM Access Key (>90 days)', resource:`${k.user_name}/${k.access_key_id}`, region:'global',
      description:`Access key ${k.access_key_id} for "${k.user_name}" is ${Math.round(Number(k.age_days))} days old. Keys >90 days must be rotated.`,
      remediationHint:`aws iam create-access-key --user-name ${k.user_name}  # update apps  then:  aws iam delete-access-key --user-name ${k.user_name} --access-key-id ${k.access_key_id}` })},
  // CloudTrail
  { id:'CT_DISABLED',
    sql:`SELECT name, is_logging, home_region FROM aws_cloudtrail_trail WHERE is_logging = false LIMIT 50`,
    mapRow:(t)=>({ id:`ct-${t.name}`, checkId:'CT_DISABLED', cisControl:'CIS-3.1',
      severity:'high', type:'CloudTrail Logging Disabled', resource:String(t.name), region:String(t.home_region),
      description:`CloudTrail trail "${t.name}" has logging disabled. No API audit trail — incident investigation impossible.`,
      remediationHint:`aws cloudtrail start-logging --name ${t.name}` })},
  { id:'CT_NO_VALIDATION',
    sql:`SELECT name, home_region FROM aws_cloudtrail_trail WHERE log_file_validation_enabled = false AND is_logging = true LIMIT 50`,
    mapRow:(t)=>({ id:`ctval-${t.name}`, checkId:'CT_NO_VALIDATION', cisControl:'CIS-3.2',
      severity:'medium', type:'CloudTrail Log Validation Disabled', resource:String(t.name), region:String(t.home_region),
      description:`Trail "${t.name}" has no log file integrity validation. Tampered logs may go undetected during forensic investigation.`,
      remediationHint:`aws cloudtrail update-trail --name ${t.name} --enable-log-file-validation` })},
  // EBS
  { id:'EBS_UNENC',
    sql:`SELECT volume_id, volume_type, size, availability_zone FROM aws_ebs_volume WHERE encrypted = false AND state = 'in-use' LIMIT 50`,
    mapRow:(v)=>({ id:`ebs-${v.volume_id}`, checkId:'EBS_UNENC', cisControl:'CIS-2.2.1',
      severity:'high', type:'Unencrypted EBS Volume', resource:String(v.volume_id), region:String(v.availability_zone),
      description:`EBS volume ${v.volume_id} (${v.volume_type}, ${v.size}GB) is unencrypted and actively attached to a running instance.`,
      remediationHint:`Snapshot ${v.volume_id} → copy-snapshot with --encrypted → create encrypted volume → stop instance → swap attachment.` })},
  // RDS
  { id:'RDS_PUBLIC',
    sql:`SELECT db_instance_identifier, engine, engine_version, region FROM aws_rds_db_instance WHERE publicly_accessible = true LIMIT 50`,
    mapRow:(r)=>({ id:`rds-${r.db_instance_identifier}`, checkId:'RDS_PUBLIC', cisControl:'CIS-2.3.2',
      severity:'critical', type:'Publicly Accessible RDS Database', resource:String(r.db_instance_identifier), region:String(r.region),
      description:`RDS instance "${r.db_instance_identifier}" (${r.engine} ${r.engine_version}) is directly accessible from the internet.`,
      remediationHint:`aws rds modify-db-instance --db-instance-identifier ${r.db_instance_identifier} --no-publicly-accessible --apply-immediately` })},
  { id:'RDS_NO_ENC',
    sql:`SELECT db_instance_identifier, engine, region FROM aws_rds_db_instance WHERE storage_encrypted = false LIMIT 50`,
    mapRow:(r)=>({ id:`rdsenc-${r.db_instance_identifier}`, checkId:'RDS_NO_ENC', cisControl:'CIS-2.3.1',
      severity:'high', type:'Unencrypted RDS Instance', resource:String(r.db_instance_identifier), region:String(r.region),
      description:`RDS instance "${r.db_instance_identifier}" (${r.engine}) has no storage encryption. DB files and backups stored in plaintext.`,
      remediationHint:`Take snapshot → aws rds copy-db-snapshot with --kms-key-id → restore encrypted instance from snapshot.` })},
  // KMS
  { id:'KMS_NO_ROT',
    sql:`SELECT id, region FROM aws_kms_key WHERE key_manager = 'CUSTOMER' AND key_state = 'Enabled' AND rotation_enabled = false LIMIT 50`,
    mapRow:(k)=>({ id:`kms-${k.id}`, checkId:'KMS_NO_ROT', cisControl:'CIS-3.8',
      severity:'medium', type:'KMS Key Rotation Disabled', resource:String(k.id), region:String(k.region),
      description:`KMS CMK ${k.id} has no automatic key rotation. A compromised key can decrypt all historical encrypted data indefinitely.`,
      remediationHint:`aws kms enable-key-rotation --key-id ${k.id}` })},
  // VPC Flow Logs
  { id:'VPC_NO_FLOW',
    sql:`SELECT v.vpc_id, v.region, v.cidr_block FROM aws_vpc v
         LEFT JOIN aws_vpc_flow_log f ON v.vpc_id = f.resource_id
         WHERE f.flow_log_id IS NULL AND v.is_default = false LIMIT 50`,
    mapRow:(v)=>({ id:`vpc-${v.vpc_id}`, checkId:'VPC_NO_FLOW', cisControl:'CIS-3.9',
      severity:'medium', type:'VPC Without Flow Logs', resource:String(v.vpc_id), region:String(v.region),
      description:`VPC ${v.vpc_id} (CIDR: ${v.cidr_block}) has no flow logs. Network forensics and lateral movement detection are not possible.`,
      remediationHint:`aws ec2 create-flow-logs --resource-type VPC --resource-ids ${v.vpc_id} --traffic-type ALL --log-destination-type cloud-watch-logs --log-group-name /aws/vpc/flowlogs` })},
  // Lambda
  { id:'LAMBDA_PUBLIC',
    sql:`SELECT name, region, runtime FROM aws_lambda_function
         WHERE policy::text LIKE '%"Principal": "*"%' OR policy::text LIKE '%"Principal":"*"%' LIMIT 50`,
    mapRow:(f)=>({ id:`lambda-${f.name}`, checkId:'LAMBDA_PUBLIC', cisControl:'LAMBDA-PUB',
      severity:'high', type:'Lambda Function With Public Access', resource:String(f.name), region:String(f.region),
      description:`Lambda "${f.name}" (${f.runtime}) has a resource policy allowing public invocation from any AWS account.`,
      remediationHint:`aws lambda remove-permission --function-name ${f.name} --statement-id PUBLIC_STATEMENT_ID` })},
  // RDS No Backup
  { id:'RDS_NO_BACKUP',
    sql:`SELECT db_instance_identifier, engine, region FROM aws_rds_db_instance WHERE backup_retention_period = 0 LIMIT 50`,
    mapRow:(r)=>({ id:`rdsbkp-${r.db_instance_identifier}`, checkId:'RDS_NO_BACKUP', cisControl:'AWS-BP',
      severity:'medium', type:'RDS Automated Backups Disabled', resource:String(r.db_instance_identifier), region:String(r.region),
      description:`RDS instance "${r.db_instance_identifier}" has automated backups disabled. Data loss is unrecoverable on instance failure.`,
      remediationHint:`aws rds modify-db-instance --db-instance-identifier ${r.db_instance_identifier} --backup-retention-period 7 --apply-immediately` })},
  // S3 logging
  { id:'S3_NO_LOG',
    sql:`SELECT name, region FROM aws_s3_bucket WHERE logging IS NULL LIMIT 50`,
    mapRow:(b)=>({ id:`s3log-${b.name}`, checkId:'S3_NO_LOG', cisControl:'CIS-3.1',
      severity:'low', type:'S3 Bucket Access Logging Disabled', resource:String(b.name), region:String(b.region),
      description:`Bucket "${b.name}" has access logging disabled. S3 access requests are not being recorded for audit or forensic purposes.`,
      remediationHint:`aws s3api put-bucket-logging --bucket ${b.name} --bucket-logging-status '{"LoggingEnabled":{"TargetBucket":"YOUR_LOG_BUCKET","TargetPrefix":"${b.name}/"}}'` })},
];

// ─── MOCK DATA (shown when Steampipe unavailable) ──────────────────────────────
const MOCK_ISSUES: SecurityIssue[] = [
  { id:'m1', checkId:'SG_OPEN', cisControl:'CIS-5.3', severity:'critical', type:'Overly Permissive Security Group',
    resource:'sg-web-server (sg-0a1b2c3d4e5f6)', region:'us-east-1',
    description:'"sg-web-server" allows unrestricted inbound traffic (0.0.0.0/0) in VPC: vpc-12345678 — Web server SG',
    remediationHint:"aws ec2 revoke-security-group-ingress --group-id sg-0a1b2c3d4e5f6 --ip-permissions '[{\"IpProtocol\":\"-1\",\"IpRanges\":[{\"CidrIp\":\"0.0.0.0/0\"}]}]'" },
  { id:'m2', checkId:'SG_OPEN', cisControl:'CIS-5.3', severity:'critical', type:'Overly Permissive Security Group',
    resource:'sg-database (sg-9z8y7x6w5v4)', region:'us-east-1',
    description:'"sg-database" allows unrestricted inbound traffic (0.0.0.0/0) in VPC: vpc-87654321 — DB SG with SSH open',
    remediationHint:"aws ec2 revoke-security-group-ingress --group-id sg-9z8y7x6w5v4 --ip-permissions '[{\"IpProtocol\":\"-1\",\"IpRanges\":[{\"CidrIp\":\"0.0.0.0/0\"}]}]'" },
  { id:'m3', checkId:'S3_PUBLIC', cisControl:'CIS-2.1.5', severity:'high', type:'Public S3 Bucket',
    resource:'customer-data-backup', region:'us-west-2',
    description:'Bucket "customer-data-backup" has public access — ACLs: ❌ Policy: ❌ IgnoreACL: ❌ Restrict: ❌',
    remediationHint:'aws s3api put-public-access-block --bucket customer-data-backup --public-access-block-configuration BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true' },
  { id:'m4', checkId:'S3_PUBLIC', cisControl:'CIS-2.1.5', severity:'high', type:'Public S3 Bucket',
    resource:'app-logs-2024', region:'eu-west-1',
    description:'Bucket "app-logs-2024" has public access — ACLs: ❌ Policy: ✅ IgnoreACL: ❌ Restrict: ✅',
    remediationHint:'aws s3api put-public-access-block --bucket app-logs-2024 --public-access-block-configuration BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true' },
  { id:'m5', checkId:'EC2_PUBLIC', cisControl:'CIS-5.6', severity:'medium', type:'Public EC2 Instance',
    resource:'web-server-prod (t3.medium)', region:'us-east-1',
    description:'Instance "i-0abc123def456" is publicly accessible — IP: 54.123.45.67 | DNS: ec2-54-123-45-67.compute-1.amazonaws.com',
    remediationHint:'Move to private subnet. Use Application Load Balancer for public traffic.' },
  { id:'m6', checkId:'EC2_PUBLIC', cisControl:'CIS-5.6', severity:'medium', type:'Public EC2 Instance',
    resource:'api-server-01 (t3.large)', region:'us-west-2',
    description:'Instance "i-0def456abc123" is publicly accessible — IP: 52.98.76.54',
    remediationHint:'Move to private subnet. Use Application Load Balancer for public traffic.' },
  { id:'m7', checkId:'IAM_NO_MFA', cisControl:'CIS-1.10', severity:'critical', type:'IAM User Without MFA',
    resource:'developer-anush', region:'global',
    description:'IAM user "developer-anush" has no MFA enabled. Console access with password only.',
    remediationHint:'Enable virtual MFA: AWS Console > IAM > Users > developer-anush > Security credentials > Assign MFA device' },
  { id:'m8', checkId:'CT_DISABLED', cisControl:'CIS-3.1', severity:'high', type:'CloudTrail Logging Disabled',
    resource:'default-trail', region:'ap-south-1',
    description:'"default-trail" has logging disabled. No AWS API audit trail is being recorded.',
    remediationHint:'aws cloudtrail start-logging --name default-trail' },
];

const PIE_COLORS = ['#dc2626','#ea580c','#ca8a04','#2563eb'];

// ─── COMPLIANCE SCORE ─────────────────────────────────────────────────────────
function getComplianceScore(issues: SecurityIssue[]) {
  // Count unique check prefixes (S3, EC2, SG, IAM, CT, EBS, RDS, KMS, VPC, LAMBDA)
  const allPrefixes = [...new Set(AWS_CHECKS.map(c => c.id.split('_')[0]))];
  const failPrefixes = [...new Set(
    issues.map(i => i.checkId?.split('_')[0]).filter(Boolean) as string[]
  )];
  const passCount = allPrefixes.filter(p => !failPrefixes.includes(p)).length;
  return { score: Math.round((passCount / allPrefixes.length) * 100), pass: passCount, total: allPrefixes.length };
}

const severityColor = (s: string) => ({
  critical: 'bg-red-100 text-red-800 border-red-200',
  high:     'bg-orange-100 text-orange-800 border-orange-200',
  medium:   'bg-yellow-100 text-yellow-800 border-yellow-200',
  low:      'bg-blue-100 text-blue-800 border-blue-200',
}[s] ?? 'bg-blue-100 text-blue-800 border-blue-200');

const severityBadge = (s: string) => ({
  critical: 'bg-red-500 text-white',
  high:     'bg-orange-500 text-white',
  medium:   'bg-yellow-500 text-white',
  low:      'bg-blue-500 text-white',
}[s] ?? 'bg-blue-500 text-white');

// ─── DASHBOARD ────────────────────────────────────────────────────────────────
export default function Dashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    publicS3Buckets:0, publicInstances:0, openSecurityGroups:0,
    totalInstances:0, criticalIssues:0, highIssues:0, totalRiskScore:0,
  });
  const [issues,       setIssues]      = useState<SecurityIssue[]>([]);
  const [prevIssues,   setPrevIssues]  = useState<SecurityIssue[]>([]);
  const [aiSummary,    setAiSummary]   = useState<string>('');
  const [generatingAI, setGeneratingAI]= useState(false);
  const [usingMock,    setUsingMock]   = useState(false);
  // NEW state
  const [expandedId,   setExpandedId] = useState<string|null>(null);
  const [ragControls,  setRagControls]= useState<RAGControl[]>([]);
  const [riskTrend,    setRiskTrend]  = useState<TrendPoint[]>([]);
  const [aiError,      setAiError]    = useState('');

  // Existing useEffect for /api/scan (unchanged)
  useEffect(() => {
    fetch('/api/scan').then(r=>r.json()).then(data=>{
      setStats(prev=>({...prev, totalRiskScore:data.riskScore,
        criticalIssues:data.severity==='CRITICAL'?1:0,
        openSecurityGroups:data.publicExposure?1:0 }));
    }).catch(()=>{});
  }, []);

  const processIssues = useCallback((raw: SecurityIssue[]): SecurityIssue[] => {
    return raw.map(issue => {
      const ri: RiskIssue = { ...issue, exposure: issue.type.includes('Public')||issue.type.includes('Permissive')?'Public':'Internal' };
      return { ...issue, riskScore:calculateRiskScore(ri), threatCategory:getThreatCategory(ri) };
    });
  }, []);

  const setMockData = useCallback(() => {
    const processed = processIssues(MOCK_ISSUES);
    setPrevIssues(processed.slice(0,4));
    setIssues(processed);
    const totalRisk = processed.reduce((s,i)=>s+(i.riskScore||0),0);
    setStats({ publicS3Buckets:2, publicInstances:2, openSecurityGroups:2, totalInstances:15,
      criticalIssues:2, highIssues:2, totalRiskScore:totalRisk });
  }, [processIssues]);

  // UPGRADED fetchSecurityData: 20 checks instead of 3
  const fetchSecurityData = useCallback(async () => {
    try {
      setUsingMock(false);
      const results = await Promise.allSettled(
        AWS_CHECKS.map(check =>
          fetch(`/api/steampipe?query=${encodeURIComponent(check.sql)}`)
            .then(r => r.ok ? r.json() : Promise.reject(r.status))
            .then((data: SteampipeResponse) => ({ check, rows: data.rows || [] }))
        )
      );

      const allIssues: SecurityIssue[] = [];
      let anySuccess = false;
      results.forEach(r => {
        if (r.status === 'fulfilled') {
          anySuccess = true;
          r.value.rows.forEach(row => {
            try { allIssues.push(r.value.check.mapRow(row)); } catch { /* skip malformed */ }
          });
        }
      });

      if (!anySuccess) throw new Error('All checks failed');

      const processed = processIssues(allIssues);
      setPrevIssues(prev => prev.length > 0 ? prev : processed);
      setIssues(processed);
      const totalRisk = processed.reduce((s,i)=>s+(i.riskScore||0), 0);
      setStats({
        publicS3Buckets:  allIssues.filter(i=>i.checkId==='S3_PUBLIC').length,
        publicInstances:  allIssues.filter(i=>i.checkId==='EC2_PUBLIC').length,
        openSecurityGroups: allIssues.filter(i=>i.checkId==='SG_OPEN').length,
        totalInstances:0, criticalIssues:processed.filter(i=>i.severity==='critical').length,
        highIssues:processed.filter(i=>i.severity==='high').length, totalRiskScore:totalRisk,
      });
      setRiskTrend(prev=>[...prev.slice(-9),
        { time:new Date().toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'}), score:totalRisk }]);

    } catch {
      setUsingMock(true);
      setMockData();
    }
  }, [processIssues, setMockData]);

  useEffect(() => { fetchSecurityData(); }, [fetchSecurityData]);

  // UPGRADED generateAISummary: sends structured issues for RAG grounding
  const generateAISummary = async () => {
    setGeneratingAI(true);
    setAiError('');
    try {
      const counts = {
        critical: issues.filter(i=>i.severity==='critical').length,
        high: issues.filter(i=>i.severity==='high').length,
        medium: issues.filter(i=>i.severity==='medium').length,
        low: issues.filter(i=>i.severity==='low').length,
      };
      const compliance = getComplianceScore(issues);

      const res = await fetch('/api/ai-summary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          issues: issues.slice(0, 8).map(i => ({
            type: i.type, description: i.description, severity: i.severity,
          })),
          riskScore: stats.totalRiskScore,
          complianceScore: compliance.score,
          counts,
        }),
      });

      if (!res.ok) throw new Error((await res.json()).error || 'API Error');
      const data = await res.json();
      setAiSummary(data.summary);
      if (data.ragControls) setRagControls(data.ragControls);
    } catch (e) {
      setAiError(e instanceof Error ? e.message : '❌ Error generating AI analysis.');
    } finally {
      setGeneratingAI(false);
    }
  };

  const drift = compareScans(prevIssues, issues);
  const compliance = getComplianceScore(issues);

  const pieData = [
    { name:'Critical', value:stats.criticalIssues },
    { name:'High',     value:stats.highIssues },
    { name:'Medium',   value:issues.filter(i=>i.severity==='medium').length },
    { name:'Low',      value:issues.filter(i=>i.severity==='low').length },
  ].filter(d=>d.value>0);

  const catData = [...new Set(issues.map(i=>i.checkId?.split('_')[0]||'Other'))].map(cat=>({
    category:cat,
    count: issues.filter(i=>i.checkId?.startsWith(cat+'_')||i.checkId===cat).length,
  })).sort((a,b)=>b.count-a.count);

  // ─── RENDER ───────────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 pb-12">

      {/* HEADER */}
      <div className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Shield className="w-10 h-10 text-blue-600"/>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">AI-Powered Threat Detection System</h1>
              <p className="text-gray-500 mt-1 text-sm font-medium">
                CSPM &amp; CWPP Security Dashboard · {AWS_CHECKS.length} Checks · RAG AI · Isolation Forest
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="bg-blue-50 border border-blue-100 px-4 py-2 rounded-lg">
              <p className="text-xs text-blue-600 font-bold uppercase tracking-wider">Risk Score</p>
              <p className="text-2xl font-black text-blue-900">{stats.totalRiskScore}</p>
            </div>
            <div className="bg-green-50 border border-green-100 px-4 py-2 rounded-lg">
              <p className="text-xs text-green-600 font-bold uppercase tracking-wider">Compliance</p>
              <p className="text-2xl font-black text-green-900">{compliance.score}%</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">

        {usingMock && (
          <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg text-sm text-yellow-800">
            ⚠️ <strong>Steampipe not reachable.</strong> Showing mock data for demonstration.
          </div>
        )}

        {/* KPI ROW (same layout as original, +compliance card) */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-2"><BarChart3 className="w-5 h-5 text-gray-400"/><h3 className="text-sm font-bold text-gray-800">Threat Risk Overview</h3></div>
            <div className="grid grid-cols-2 gap-2">
              <div className="bg-gray-100 border border-gray-300 p-4 rounded-lg shadow-sm">
                <p className="text-[10px] text-gray-800 uppercase font-bold">Total Issues</p>
                <p className="text-3xl font-extrabold text-gray-900">{issues.length}</p>
              </div>
              <div className="bg-red-50 p-2 rounded">
                <p className="text-[10px] text-red-400 uppercase font-bold">Critical</p>
                <p className="text-xl font-bold text-red-600">{stats.criticalIssues}</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-2"><TrendingUp className="w-5 h-5 text-gray-400"/><h3 className="text-sm font-bold text-gray-600">Configuration Drift</h3></div>
            <div className="grid grid-cols-2 gap-2">
              <div className="bg-green-50 p-2 rounded"><p className="text-[10px] text-green-500 uppercase font-bold">New Detected</p><p className="text-xl font-bold text-green-600">+{drift.added.length}</p></div>
              <div className="bg-gray-50 p-2 rounded"><p className="text-[10px] text-gray-400 uppercase font-bold">Resolved</p><p className="text-xl font-bold text-gray-500">-{drift.removed.length}</p></div>
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-2"><CheckCircle className="w-5 h-5 text-green-500"/><h3 className="text-sm font-bold text-gray-600">Compliance Score</h3></div>
            <p className="text-3xl font-black text-green-600">{compliance.score}%</p>
            <p className="text-xs text-gray-500 mt-1">{compliance.pass}/{compliance.total} service categories passing</p>
          </div>

          <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-center gap-3 mb-2"><Zap className="w-5 h-5 text-yellow-500"/><h3 className="text-sm font-bold text-gray-600">Active Threat Mitigation</h3></div>
            <div className="flex items-center gap-4">
              <div className="flex-1 bg-yellow-50 p-2 rounded border border-yellow-100">
                <p className="text-[10px] text-yellow-600 uppercase font-bold">AI Mitigation Strategy</p>
                <p className="text-xs text-yellow-800 mt-1">Analyzing {stats.criticalIssues} critical vectors. RAG-grounded CIS/NIST remediation ready.</p>
              </div>
            </div>
          </div>
        </div>

        {/* CHARTS ROW — NEW */}
        {(pieData.length > 0 || catData.length > 0) && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {pieData.length > 0 && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
                <h3 className="text-sm font-bold text-gray-700 mb-3">Severity Distribution</h3>
                <ResponsiveContainer width="100%" height={170}>
                  <PieChart>
                    <Pie data={pieData} cx="50%" cy="50%" outerRadius={65} dataKey="value"
                      label={({name,value})=>`${name}:${value}`} labelLine={false} fontSize={10}>
                      {pieData.map((_,i)=><Cell key={i} fill={PIE_COLORS[i%PIE_COLORS.length]}/>)}
                    </Pie>
                    <Tooltip/>
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}
            {catData.length > 0 && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
                <h3 className="text-sm font-bold text-gray-700 mb-3">Issues by Service</h3>
                <ResponsiveContainer width="100%" height={170}>
                  <BarChart data={catData.slice(0,6)} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0"/>
                    <XAxis type="number" tick={{fontSize:10}}/>
                    <YAxis dataKey="category" type="category" tick={{fontSize:10}} width={55}/>
                    <Tooltip/>
                    <Bar dataKey="count" fill="#3b82f6" radius={3}/>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
            {riskTrend.length > 1 && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5">
                <h3 className="text-sm font-bold text-gray-700 mb-3">Risk Score Trend</h3>
                <ResponsiveContainer width="100%" height={170}>
                  <LineChart data={riskTrend}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0"/>
                    <XAxis dataKey="time" tick={{fontSize:9}}/>
                    <YAxis tick={{fontSize:9}}/>
                    <Tooltip/>
                    <Line type="monotone" dataKey="score" stroke="#f59e0b" strokeWidth={2} dot={false}/>
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>
        )}

        {/* MAIN CONTENT — same 3-column layout as original */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">

            {/* CSPM ISSUES — upgraded with CIS badges + expandable remediation */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
              <div className="px-6 py-4 bg-gray-50 border-b border-gray-200 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Activity className="w-5 h-5 text-blue-600"/>
                  <h2 className="text-xl font-bold text-gray-900">CSPM Configuration Threat Detection</h2>
                  <span className="text-xs bg-gray-200 text-gray-600 px-2 py-0.5 rounded-full">{AWS_CHECKS.length} checks</span>
                </div>
                <button onClick={fetchSecurityData} className="text-xs font-bold text-blue-600 hover:text-blue-800 uppercase tracking-wider">
                  Refresh Scan
                </button>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {issues.length === 0 ? (
                    <div className="text-center py-12">
                      <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-3"/>
                      <p className="text-green-600 font-bold">All {AWS_CHECKS.length} checks passed!</p>
                    </div>
                  ) : issues.map(issue => (
                    <div key={issue.id} className={`${severityColor(issue.severity)} rounded-lg border overflow-hidden`}>
                      {/* Issue card header — click to expand */}
                      <div className="p-4 flex items-start gap-4 cursor-pointer"
                        onClick={()=>setExpandedId(expandedId===issue.id?null:issue.id)}>
                        <div className={`mt-1 p-2 rounded-lg ${severityBadge(issue.severity)}`}>
                          <ShieldAlert className="w-4 h-4"/>
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1 flex-wrap">
                            <span className="text-[10px] font-black uppercase px-1.5 py-0.5 rounded bg-white/50 border border-current">
                              {issue.threatCategory}
                            </span>
                            {/* CIS badge — NEW */}
                            {issue.cisControl && (
                              <span className="text-[10px] font-black px-1.5 py-0.5 rounded bg-blue-100 text-blue-700 border border-blue-200">
                                {issue.cisControl}
                              </span>
                            )}
                            <h3 className="font-bold text-sm">{issue.type}</h3>
                          </div>
                          <p className="text-xs opacity-80 mb-2">{issue.description}</p>
                          <div className="flex items-center gap-4 text-[10px] font-bold uppercase tracking-tight opacity-60">
                            <span className="flex items-center gap-1"><Lock className="w-3 h-3"/>{issue.resource}</span>
                            <span className="flex items-center gap-1"><Zap className="w-3 h-3"/>Risk: {issue.riskScore}</span>
                            {issue.region && <span>{issue.region}</span>}
                          </div>
                        </div>
                        {expandedId===issue.id
                          ? <ChevronUp className="w-4 h-4 opacity-40 flex-shrink-0"/>
                          : <ChevronDown className="w-4 h-4 opacity-40 flex-shrink-0"/>}
                      </div>
                      {/* Expandable remediation — NEW */}
                      {expandedId===issue.id && issue.remediationHint && (
                        <div className="border-t border-current/20 px-4 pb-4 pt-2 bg-white/40">
                          <p className="text-[10px] font-black uppercase mb-1 flex items-center gap-1">
                            <Terminal className="w-3 h-3"/> Remediation Command
                          </p>
                          <code className="text-[11px] font-mono break-all opacity-90">{issue.remediationHint}</code>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* CWPP PANEL — same design, now shows Isolation Forest features */}
            <div className="bg-slate-900 rounded-xl shadow-xl border border-slate-800 overflow-hidden">
              <div className="px-6 py-4 border-b border-slate-800 flex items-center gap-3 bg-slate-900/50">
                <Terminal className="w-5 h-5 text-emerald-400"/>
                <h2 className="text-xl font-bold text-white">CWPP Runtime Threat Detection</h2>
                <span className="ml-auto px-2 py-0.5 rounded text-[10px] font-black bg-purple-500/10 text-purple-400 border border-purple-500/20 uppercase tracking-widest">
                  Isolation Forest ML
                </span>
              </div>
              <div className="p-6 space-y-4">
                {mockRuntimeEvents.map(event => {
                  const { score, threatLevel, contributingFeatures, recommendation } = calculateAnomalyScore(event);
                  return (
                    <div key={event.instanceId} className="bg-slate-800/50 border border-slate-700 rounded-lg p-4 space-y-3">
                      <div className="flex items-center gap-6">
                        <div className="p-3 bg-slate-800 rounded-full border border-slate-700">
                          <Cpu className={`w-6 h-6 ${threatLevel==='HIGH'?'text-red-400 animate-pulse':'text-emerald-400'}`}/>
                        </div>
                        <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-4">
                          <div><p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Instance ID</p><p className="text-xs text-slate-300 font-mono truncate">{event.instanceId}</p></div>
                          <div><p className="text-[10px] text-slate-500 font-bold uppercase mb-1">CPU Load</p><p className={`text-sm font-bold ${event.cpuUsage>80?'text-red-400':'text-slate-300'}`}>{event.cpuUsage}%</p></div>
                          <div><p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Suspicious Ports</p><p className="text-xs text-slate-300">{event.suspiciousPorts.length>0?event.suspiciousPorts.join(', '):'None'}</p></div>
                          <div className="text-right">
                            <p className="text-[10px] text-slate-500 font-bold uppercase mb-1">Anomaly Index</p>
                            <span className={`text-[10px] font-black px-2 py-1 rounded border ${
                              threatLevel==='HIGH'?'bg-red-500/20 text-red-400 border-red-500/30':
                              threatLevel==='MEDIUM'?'bg-yellow-500/20 text-yellow-400 border-yellow-500/30':
                              'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                            }`}>{threatLevel} ({score})</span>
                          </div>
                        </div>
                      </div>
                      {/* Isolation Forest contributing features — NEW */}
                      {contributingFeatures.length > 0 && (
                        <div className="bg-slate-900/60 rounded p-2 space-y-1">
                          <p className="text-[9px] text-slate-500 font-bold uppercase">Isolation Forest — Anomaly Signals:</p>
                          {contributingFeatures.map(f=>(
                            <p key={f} className="text-[10px] text-slate-400">• {f}</p>
                          ))}
                          <p className="text-[10px] text-slate-500 italic mt-1">{recommendation}</p>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* RIGHT SIDEBAR */}
          <div className="space-y-8">
            {/* AI PANEL — RAG-grounded, shows retrieved controls */}
            <div className="bg-gradient-to-b from-indigo-600 to-blue-700 rounded-xl shadow-lg border border-indigo-500/30 overflow-hidden text-white">
              <div className="p-6 border-b border-white/10 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-6 h-6 text-indigo-200"/>
                  <div>
                    <h2 className="text-xl font-bold">AI Threat Analysis</h2>
                    <p className="text-[10px] text-indigo-300 mt-0.5">RAG · CIS/NIST · LLaMA 3.3 70B</p>
                  </div>
                </div>
                <button onClick={generateAISummary} disabled={generatingAI}
                  className="p-2 bg-white/10 hover:bg-white/20 rounded-lg transition-colors disabled:opacity-50">
                  <Activity className={`w-4 h-4 ${generatingAI?'animate-spin':''}`}/>
                </button>
              </div>
              <div className="p-6 space-y-4">
                {/* Retrieved CIS/NIST controls — NEW */}
                {ragControls.length > 0 && (
                  <div>
                    <p className="text-[10px] text-indigo-300 font-black uppercase tracking-widest mb-2">📚 Retrieved CIS/NIST Controls</p>
                    <div className="space-y-1.5">
                      {ragControls.map(c=>(
                        <div key={c.id} className="bg-white/10 rounded px-2 py-1.5 flex items-start gap-2">
                          <span className="text-[10px] font-mono text-yellow-300 font-bold flex-shrink-0 mt-0.5">{c.id}</span>
                          <span className="text-[10px] text-indigo-100 leading-tight">{c.title}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {aiError && (
                  <div className="bg-red-500/20 border border-red-400/30 rounded p-3">
                    <p className="text-xs text-red-200">{aiError}</p>
                  </div>
                )}

                {aiSummary ? (
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/10">
                    <pre className="text-xs text-indigo-50 leading-relaxed whitespace-pre-wrap font-sans">{aiSummary}</pre>
                  </div>
                ) : (
                  <div className="text-center py-8 opacity-60">
                    <Activity className="w-12 h-12 mx-auto mb-3 opacity-20"/>
                    <p className="text-xs uppercase font-black tracking-widest">Ready for Deep Scan</p>
                    <p className="text-[10px] text-indigo-300 mt-1">Retrieves CIS/NIST controls before analysis</p>
                  </div>
                )}

                <button onClick={generateAISummary} disabled={generatingAI}
                  className="w-full py-3 bg-white text-indigo-700 rounded-xl font-black text-xs uppercase tracking-widest hover:bg-indigo-50 transition-all shadow-xl disabled:opacity-50">
                  {generatingAI ? 'Retrieving Controls & Synthesizing…' : 'Run Neural Analysis'}
                </button>
              </div>
            </div>

            {/* SECURITY INSIGHTS (original — kept exactly) */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-sm font-black text-gray-900 uppercase tracking-widest mb-4">Security Insights</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3 text-xs"><div className="w-2 h-2 rounded-full bg-red-500"/>
                  <span className="font-bold text-gray-700">Data Exposure Risk:</span>
                  <span className="ml-auto text-gray-500">{issues.filter(i=>i.threatCategory==='Data Exposure').length}</span></div>
                <div className="flex items-center gap-3 text-xs"><div className="w-2 h-2 rounded-full bg-orange-500"/>
                  <span className="font-bold text-gray-700">Attack Surface:</span>
                  <span className="ml-auto text-gray-500">{issues.filter(i=>i.threatCategory==='Attack Surface').length}</span></div>
                <div className="flex items-center gap-3 text-xs"><div className="w-2 h-2 rounded-full bg-blue-500"/>
                  <span className="font-bold text-gray-700">Network Exposure:</span>
                  <span className="ml-auto text-gray-500">{issues.filter(i=>i.threatCategory==='Network Exposure').length}</span></div>
                <div className="flex items-center gap-3 text-xs border-t border-gray-100 pt-3"><div className="w-2 h-2 rounded-full bg-purple-500"/>
                  <span className="font-bold text-gray-700">CWPP Anomalies:</span>
                  <span className="ml-auto text-gray-500">
                    {mockRuntimeEvents.filter(e=>calculateAnomalyScore(e).threatLevel!=='LOW').length}
                  </span></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
