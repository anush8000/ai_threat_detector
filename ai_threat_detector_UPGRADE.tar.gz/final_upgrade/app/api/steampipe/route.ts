// app/api/steampipe/route.ts
// UPGRADED: fixes connection leak, adds SQL injection protection, proper pooling

import { NextRequest, NextResponse } from 'next/server';
import { Pool } from 'pg';

const pool = new Pool({
  user: 'steampipe',
  password: process.env.STEAMPIPE_PASSWORD || 'your_steampipe_password',
  host: '127.0.0.1',
  port: 9193,
  database: 'steampipe',
  max: 10,                        // max pool connections
  connectionTimeoutMillis: 8000,  // 8s connect timeout
  idleTimeoutMillis: 30000,       // release idle connections after 30s
});

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const query = searchParams.get('query');

  if (!query) {
    return NextResponse.json({ error: 'Query parameter is required' }, { status: 400 });
  }

  // ── SQL injection protection: only allow SELECT statements ──
  if (!query.trim().toUpperCase().startsWith('SELECT')) {
    return NextResponse.json({ error: 'Only SELECT queries are permitted' }, { status: 403 });
  }

  const client = await pool.connect();
  try {
    const result = await client.query(query);
    return NextResponse.json({ rows: result.rows, rowCount: result.rowCount });
  } catch (error) {
    console.error('Steampipe error:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Query failed', rows: [], rowCount: 0 },
      { status: 500 }
    );
  } finally {
    client.release(); // ← always releases, even on error (was leaking before)
  }
}
